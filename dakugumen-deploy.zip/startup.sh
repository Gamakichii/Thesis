#!/bin/bash
cd /home/site/wwwroot/phishing_api
gunicorn --bind=0.0.0.0 --port=8000 --workers=1 --timeout=600 app:app